<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="registration.css?v=<?php echo time(); ?>"> -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <link rel="stylesheet" href="registration.css">
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <title>Store</title>
</head>
<body>
   
      
<nav class="nav-bar">

  



        <ul class="nav-links">
            <li> <a  href="../store.php"> Store </a></li>
            <li> <a  href="login.php"> Login </a></li>


        </ul>
        </nav>


   
    
        <form action="" class="reg-form form-group" method="post"> 

        
            <label for="username"> Username </label>
            <input type="text" class="form-control" name="username" placeholder="Enter your username"> <br>
            
            <label for="email"> Email </label>
            <input type="email" class="form-control" name="email" placeholder="Enter your email"> <br>
            
            
            <label for="password"> Enter Password </label>
            <input type="password" class="form-control" name="password" placeholder="Enter your password"> <br>
            
            <label for="confirm_password"> Confirm Password </label>
            <input type="password" class="form-control" name="confirm_password" placeholder="Confirm your password"> <br>

            <button type="submit" class="btn btn-primary">Sign In</button>

        </form>



        
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>


        
    

   
    
</body>
</html>
<?php
require_once "config.php";




$username = $email = $password = $confirm_password = "";
$username_err = $email_err =  $password_err = $confirm_password_err = "";

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    if (empty(trim($_POST['username']))) {
        $username_err = "Full name cannot be blank";
    } 
    else {
        $username = trim($_POST['username']);
    }

    // Check if email is empty
    if (empty(trim($_POST["email"]))) {
        $email_err = "Email cannot be blank";
    } else {
        $sql = "SELECT id FROM users WHERE email = ?";
        $stmt = mysqli_prepare($conn, $sql);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "s", $param_email);

            // Set the value of param username
            $param_email= trim($_POST['email']);

            // Try to execute this statement
            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);
                if (mysqli_stmt_num_rows($stmt) == 1) {
                    $email_err = "This email is already taken";
                    echo $email_err;
                } else {
                    $email = trim($_POST['email']);
                }
            } else {
                echo "Something went wrong";
            }
        }
    }

    mysqli_stmt_close($stmt);


  
   
 

// Check for password
    if (empty(trim($_POST['password']))) {
        $password_err = "Password cannot be blank";
    } elseif (strlen(trim($_POST['password'])) < 5) {
        $password_err = "Password cannot be less than 5 characters";
    } else {
        $password = trim($_POST['password']);
    }

// Check for confirm password field
    if (trim($_POST['password']) != trim($_POST['confirm_password'])) {
        $password_err = "Passwords should match";
    }


// If there were no errors, go ahead and insert into the database
    if (empty($username_err) && empty($email_err) && empty($password_err) && empty($confirm_password_err)) {
        $sql = "INSERT INTO users (username, email, password) VALUES (?,?,?)";
        $stmt = mysqli_prepare($conn, $sql);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "sss", $param_username, $param_email, $param_password);

            // Set these parameters
            $param_username = $username;
            $param_email = $_POST["email"];
            
            $param_password = password_hash($password, PASSWORD_DEFAULT);
            

            // Try to execute the query
            if (mysqli_stmt_execute($stmt)) {
                header("location: login.php");
            } else {
                echo "Something went wrong... cannot redirect!";
            }
            
        }
        mysqli_stmt_close($stmt);
        
    }
    mysqli_close($conn);
}

?>



