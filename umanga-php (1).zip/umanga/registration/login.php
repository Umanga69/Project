<?php
//This script will handle login
session_start();
if(isset($_SESSION['email']))
{
    header("location:../store.php");
    exit;
}
require_once "config.php";
$email = $password = "";
$err = "";
// if request method is post
if ($_SERVER['REQUEST_METHOD'] == "POST"){

    if(empty(trim($_POST['email'])) || empty(trim($_POST['password'])))
    {
        $err = "Please enter email and password";
        echo $err;
    }
    else{
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);
       
    }


    if(empty($err))
    {
        $sql = "SELECT id, email, password FROM users WHERE email = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "s", $param_email);
        $param_email = $email;

// Try to execute this statement
        if(mysqli_stmt_execute($stmt)){
            mysqli_stmt_store_result($stmt);
            if(mysqli_stmt_num_rows($stmt) == 1)
            {
                mysqli_stmt_bind_result($stmt, $id, $email, $hashed_password);
                if(mysqli_stmt_fetch($stmt))
                {
                    if(password_verify($password, $hashed_password))
                    {
// this means the password is correct. Allow user to login
                        session_start();
                        $_SESSION["email"] = $email;
                        $_SESSION["id"] = $id;
                        $_SESSION["loggedin"] = true;
                     

//Redirect user to welcome page
                        header("location:../store.php");

                    }
                }

            }

        }
    }


}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <link rel="stylesheet" href="registration.css?v=<?php echo time(); ?>">
    
    <link rel="shortcut icon" href="favicon.ico" type="image/x-icon">
    <title>AMS</title>
</head>
<body>
<div class="nav-bar">
   

        <ul class="nav-links">
            <li> <a href="../store.php"> Store </a></li>
            <li> <a href="register.php"> Register </a></li>


        </ul>


    </div>







    
    
    <form action="login.php"  class="log-form" method="post">
        <label for="name">Email:</label>
        <input type="text" class="form-control" name="email" id="email" placeholder="Enter email"> <br>

        

        <label for="password">Password:</label>
        <input type="password" class="form-control" name="password" id="password" placeholder="Enter Password"> <br>
        <button type="submit" class="btn btn-primary" >Submit</button>
    </form>


</body>
</html>