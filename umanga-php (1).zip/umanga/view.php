<?php
require_once "config.php";
$sql = "SELECT * FROM products";
$result=mysqli_query($conn,$sql)
?>
<?php //include "../header.php"?>
    <html>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
        <link rel="stylesheet" href="store.css?v=<?php echo time();?>">
    <head><title>View</title></head>
    <body>
    <div class="nav-bar">


        <ul class="nav-links">
            <li> <a href="add.php"> Add </a></li>
            <li> <a href="registration/logout.php"> Logout </a></li>


        </ul>


    </div>
    
    </form>
    <table class="table table-striped table-dark">
        <tr>
            <th class="viewText" scope="col">Product Id</th>
            <th class="viewText" scope="col">Image</th>
            <th class="viewText" scope="col">Product Name</th>
            <th class="viewText" scope="col">Product Code</th>
            <th class="viewText" scope="col">Cost</th>
            <th class="viewText" scope="col">Edit</th>
            <th class="viewText" scope="col">Delete</th>
        </tr>
        <?php foreach ($result as $row){ ?>
            <tr>
                <td scope="row"><?php echo$row['id']?></td>
                <td><img src="upload/<?php echo $row['image']?>" height= "200px" width="350px"></td>
                <td class="viewText"><?php echo $row['product_name']?></td>
                <td class="viewText"><?php echo $row['code']?></td>
                <td class="viewText"><?php echo $row['cost']?></td>
                
                <td><a class="viewText" href="edit.php?id=<?php echo $row["id"]?>">Edit</a></td>
                <td><a class="viewText" href="delete.php? id=<?php echo $row["id"]?>">Delete</a> </td>
            </tr>

        <?php } ?>
    </table>
    </body>
    </html>
<?php //include "../footer.php"?>