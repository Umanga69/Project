<?php
require_once "config.php";

if (isset($_POST["id"]) && !empty($_POST["id"]) && $_POST["yn"]=="Yes" ) {
    $sql = "DELETE FROM products WHERE id = ?";
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "i", $param_id);
        //set parameter

        $param_id = $_GET["id"];
        if (mysqli_stmt_execute($stmt)) {
            header("location: view.php");
        }
    }
}
?>

<html>
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <link rel="stylesheet" href="store.css?v=<?php echo time();?>">
    <title>Delete Product</title>
</head>
<body>

<div class="nav-bar">


<ul class="nav-links">
    <li> <a href="store.php"> Store </a></li>
    <li> <a href="logout.php"> Logout </a></li>


</ul>


</div>

<h2>Delete Product</h2>
<form action="" method="post">
    <input class="form-control" type="hidden" name="id" value="<?php echo trim($_GET["id"]); ?>">
    <p>Do you want to delete this product ?</p>
    <p>
        <input type="submit" class="btn btn-primary" name="yn" value="Yes">
        <button class="btn btn-primary bot"><a href="view.php">No</a></button>
    </p>

</form>
</body>
</html>