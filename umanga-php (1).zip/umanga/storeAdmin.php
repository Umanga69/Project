<?php


?>


<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <link rel="stylesheet" href="store.css?v=<?php echo time();?>">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Store Admin</title>
</head>
<body>
<div class="nav-bar">
        <ul class="nav-links">
            
            <li><a href="store.php">Store</a></li>
            <li><a href="registration/logout.php">Logout</a></li>
        </ul>
    </div>

    <div class="main">


            <a href="add.php"><button type="button" class="btn btn-primary add-btn">Add an Item</button></a>
            <a href="view.php"><button type="button" class="btn btn-primary view-btn">View & Edit Items</button></a>
            
     

</div>

    
</body>
</html>