<?php
require_once "config.php";

// Define variables and initialize with empty values
$product_name= $cost= "";
$product_name_err = $cost_err =  "";

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
// Validate first name
    $input_product_name = trim($_POST["product_name"]);
    if (empty($input_product_name)) {
        $product_name_err = "Please enter a first name.";
        echo "Please enter a first name.";

    } elseif (!filter_var($input_product_name, FILTER_VALIDATE_REGEXP, array("options" => array("regexp" => "/^[a-zA-Z\s]+$/")))) {
        $product_name_err = "Please enter a valid first name.";
        echo "Please enter a valid first name.";

    } else {
        $product_name = $input_product_name;
    }



// Validate last name
    $input_cost = trim($_POST["cost"]);
    if (empty($input_cost)) {
        $cost_err = "Please enter a last name.";
        echo "Please enter a last name.";
    } 
     else {
        $cost = $input_cost;
    }



    if (empty($product_name_err_err) && empty($cost_err) ) {
// Prepare an insert statement

        $temp_name=$_FILES['image']['tmp_name'];
        $filename=$_FILES['image']['name'];
        $folder = "upload/".$filename;
        if (move_uploaded_file($temp_name, $folder))  {
            $msg = "Image uploaded successfully";
        }else{
            $msg = "Failed to upload image";
        }

        $sql = "INSERT INTO products (product_name, code, cost,image) VALUES (?,?, ?, ?)";

        if ($stmt = mysqli_prepare($conn, $sql)) {
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ssss", $product_name, $code, $cost, $filename);

            // Set parameters
            $product_name = trim($_POST['product_name']);
            $code = trim($_POST['code']);
            $cost = trim($_POST['cost']);
            $filename=$_FILES['image']['name'];

            // Attempt to execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                header("location: view.php");
            } else {
                echo "ERROR: Could not execute query: $sql. " . mysqli_error($conn);
            }
        } else {
            echo "ERROR: Could not prepare query: $sql. " . mysqli_error($conn);
        }

// Close statement
        mysqli_stmt_close($stmt);

// Close connection
        mysqli_close($conn);
    }
}
?>


<!doctype html>
<html lang="en">
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <link rel="stylesheet" href="store.css?v=<?php echo time();?>">
    <title>Form</title>
</head>
<body>
<div class="nav-bar">


<ul class="nav-links">
    <li> <a href="store.php"> Store </a></li>
    <li> <a href="registration/logout.php"> Logout </a></li>


</ul>


</div>
<form action="" class="form-group addForm" method="post" enctype="multipart/form-data">
    Product Name: <input class="form-control" type="text" placeholder="Enter Product Name" name="product_name" > <br>
    Product Code: <input class="form-control" type="text" placeholder="Enter Product Code" name="code" > <br>
    Cost: <input type="text" placeholder="Enter Cost" name="cost"> <br>
    Upload Image: <input class="form-control" type="file" placeholder="Upload Image" name="image" required> <br>
    <input type="submit" class="btn btn-primary" value="Submit">
</form>

</body>
</html>