<?php
session_start();
if(!isset($_SESSION["email"])){
  header("location:registration/register.php");
}
if($_SESSION["email"]=="umanga.khatiwada@sifal.deerwalk.edu.np"){
    header("location:storeAdmin.php");
}
require_once "config.php";
$sql = "SELECT * FROM products";
$result=mysqli_query($conn,$sql)
?>
    <html>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
        <link rel="stylesheet" href="store.css?v=<?php echo time();?>">
        
    <head><title>Store</title></head>
    <body>
    <div class="nav-bar">
      


        <ul class="nav-links">
        <div class="row">
        <div class="col">
          <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#cart">Cart (<span class="total-count"></span>)</button><button class="clear-cart btn btn-danger">Clear Cart</button></div>
    </div>
            <li> <a href="registration/logout.php"> Logout </a></li>


        </ul>


    </div>

    <table class="table table-striped table-dark" border="1">
        <tr>
            <th>id</th>
            <th>Image</th>
            <th>Product Name</th>
            <th>Cost</th>
            <th>Buy</th>
            
            
        </tr>
        <?php foreach ($result as $row){  ?>
            <tr>
                <td><?php echo$row['id']?></td>
                <td><img src="upload/<?php echo $row['image']?>" height= "200px" width="350px"></td>
                <td><?php echo $row['product_name']?></td>
                <td class="price"><?php echo (int) $row['cost'];?></td>
                <td> <a href="#"  data-name="<?php echo $row["product_name"]; ?>" data-price=<?php echo (int) $row['cost'];?> class="add-to-cart data btn btn-primary">Add to cart</a></td>
                
                
            </tr>

        <?php } ?>

      
        
        <div class="show-table">
    
    </div>
    <div class="modal fade" id="cart" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Cart</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <table class="show-cart table">
          
        </table>
        <div>Total price: $<span class="total-cart"></span></div>
      </div>
      
  </div>
</div> 


    </table>
    
  
        
<script type="text/javascript" src="https://code.jquery.com/jquery-1.7.1.min.js?v=<?php echo time(); ?>"></script>
    <script src="store.js?v=<?php echo time(); ?>"></script>
    </body>
    </html>
